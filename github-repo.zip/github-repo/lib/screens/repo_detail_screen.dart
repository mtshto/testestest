import 'package:flutter/material.dart';
import 'package:githubrepo/components/all.dart';
import 'package:githubrepo/components/avatar.dart';
import 'package:githubrepo/constants/typography.dart';
import 'package:githubrepo/models/repository.dart';

import '../components/app_bar.dart';
import '../components/search_bar.dart';
import '../models/owner.dart';

class RepoDetailScreen extends StatefulWidget {
  const RepoDetailScreen({Key? key}) : super(key: key);

  @override
  State<RepoDetailScreen> createState() => _RepoDetailScreenState();
}

class _RepoDetailScreenState extends State<RepoDetailScreen> {
  Repository user = Repository(
    id: 10,
    name: "Fiap",
    owner: Owner(
      login: "Felipe",
      avatar: "https://avatars.githubusercontent.com/u/7546521?v=4",
    ),
    htmlUrl: "https://github.com/josecastillolema/fiap",
    description: "Aplicações para os cursos de pós-graduação da FIAP",
    url: "https://api.github.com/repos/josecastillolema/fiap",
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        text: 'Detalhes',
      ),
      body: Container(
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 20),
              CustomAvatar(
                avatarUrl: user.owner!.avatar ?? '',
                radius: 60,
              ),
              SizedBox(height: 16),
              CustomText(
                  text: 'Repositorio: ${user.name}',
                  style: TypographyType.label),
              SizedBox(height: 8),
              CustomText(
                text: 'Dono: ${user.owner!.login}',
                style: TypographyType.label,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
